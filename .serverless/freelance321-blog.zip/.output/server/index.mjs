globalThis._importMeta_={url:import.meta.url,env:process.env};export { z as handler } from './chunks/nitro/aws-lambda.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
//# sourceMappingURL=index.mjs.map
