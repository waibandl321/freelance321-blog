const client_manifest = {
  "VList.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VList.a3206c89.css",
    "src": "VList.css"
  },
  "_VContainer.6bc1e896.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "VContainer.6bc1e896.js",
    "imports": [
      "_tag.e5d9a538.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_VList.4109912f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VList.a3206c89.css"
    ],
    "file": "VList.4109912f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.e5d9a538.js"
    ]
  },
  "VList.a3206c89.css": {
    "file": "VList.a3206c89.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tag.e5d9a538.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tag.96658eb4.css"
    ],
    "file": "tag.e5d9a538.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "tag.96658eb4.css": {
    "file": "tag.96658eb4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_vue.f36acd1f.633f6342.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.633f6342.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "layouts/default.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "default.6c97b9c2.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "default.2dc20fc3.js",
    "imports": [
      "_VList.4109912f.js",
      "_tag.e5d9a538.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.6c97b9c2.css": {
    "file": "default.6c97b9c2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-404.7fc72018.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-404.7ec41d01.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_vue.f36acd1f.633f6342.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.7fc72018.css": {
    "file": "error-404.7fc72018.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-500.c5df6088.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-500.1d3ae8bb.js",
    "imports": [
      "_vue.f36acd1f.633f6342.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.c5df6088.css": {
    "file": "error-500.c5df6088.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.2d4b5bd4.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "pages/about/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.3b8445b1.js",
    "imports": [
      "_vue.f36acd1f.633f6342.js",
      "_VContainer.6bc1e896.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.e5d9a538.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/about/index.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.d9d808de.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.9fbfbd47.js",
    "imports": [
      "_vue.f36acd1f.633f6342.js",
      "_VContainer.6bc1e896.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.e5d9a538.js",
      "_VList.4109912f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.d9d808de.css": {
    "file": "index.d9d808de.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/privacy/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.527095e7.js",
    "imports": [
      "_vue.f36acd1f.633f6342.js",
      "_VContainer.6bc1e896.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.e5d9a538.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/privacy/index.vue"
  },
  "pages/sitemap/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.249350cc.js",
    "imports": [
      "_vue.f36acd1f.633f6342.js",
      "_VContainer.6bc1e896.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.e5d9a538.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sitemap/index.vue"
  },
  "tag.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tag.96658eb4.css",
    "src": "tag.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
