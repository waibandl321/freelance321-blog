import { createVNode } from 'vue';
import { m as makeComponentProps, a as makeTagProps, u as useRender } from './tag-749e511f.mjs';
import { p as propsFactory, g as genericComponent, h as useRtl } from '../server.mjs';

const makeVContainerProps = propsFactory({
  fluid: {
    type: Boolean,
    default: false
  },
  ...makeComponentProps(),
  ...makeTagProps()
}, "VContainer");
const VContainer = genericComponent()({
  name: "VContainer",
  props: makeVContainerProps(),
  setup(props, _ref) {
    let {
      slots
    } = _ref;
    const {
      rtlClasses
    } = useRtl();
    useRender(() => createVNode(props.tag, {
      "class": ["v-container", {
        "v-container--fluid": props.fluid
      }, rtlClasses.value, props.class],
      "style": props.style
    }, slots));
    return {};
  }
});

export { VContainer as V };
//# sourceMappingURL=VContainer-11c19704.mjs.map
