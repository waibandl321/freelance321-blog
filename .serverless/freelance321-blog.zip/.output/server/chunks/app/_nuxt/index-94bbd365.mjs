import { u as useHead } from './index-6a088328.mjs';
import { capitalize, computed, h, createVNode, withDirectives, resolveDirective, mergeProps, withCtx, openBlock, createBlock, Fragment, renderList, createCommentVNode, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import { V as VContainer } from './VContainer-11c19704.mjs';
import { m as makeComponentProps, a as makeTagProps, u as useRender } from './tag-749e511f.mjs';
import { d as breakpoints, p as propsFactory, g as genericComponent, e as provideDefaults, I as IconValue, m as makeThemeProps, f as provideTheme } from '../server.mjs';
import { c as createSimpleFunctional, m as makeDensityProps, V as VAvatar, a as VDefaultsProvider, b as makeBorderProps, d as makeDimensionProps, e as makeElevationProps, f as makeLoaderProps, g as makeLocationProps, h as makePositionProps, i as makeRoundedProps, j as makeRouterProps, k as makeVariantProps, R as Ripple, u as useBorder, l as useVariant, n as useDensity, o as useDimension, p as useElevation, q as useLoader, r as useLocation, s as usePosition, t as useRounded, v as useLink, w as VImg, L as LoaderSlot, x as genOverlays, y as VList, z as VListSubheader, A as VListItem, B as VListItemTitle, C as VListItemSubtitle, D as VDivider } from './VList-00bd96cd.mjs';
import '@unhead/shared';
import '../../nitro/aws-lambda.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'unhead';
import 'vue-router';

const breakpointProps = (() => {
  return breakpoints.reduce((props, val) => {
    props[val] = {
      type: [Boolean, String, Number],
      default: false
    };
    return props;
  }, {});
})();
const offsetProps = (() => {
  return breakpoints.reduce((props, val) => {
    const offsetKey = "offset" + capitalize(val);
    props[offsetKey] = {
      type: [String, Number],
      default: null
    };
    return props;
  }, {});
})();
const orderProps = (() => {
  return breakpoints.reduce((props, val) => {
    const orderKey = "order" + capitalize(val);
    props[orderKey] = {
      type: [String, Number],
      default: null
    };
    return props;
  }, {});
})();
const propMap$1 = {
  col: Object.keys(breakpointProps),
  offset: Object.keys(offsetProps),
  order: Object.keys(orderProps)
};
function breakpointClass$1(type, prop, val) {
  let className = type;
  if (val == null || val === false) {
    return void 0;
  }
  if (prop) {
    const breakpoint = prop.replace(type, "");
    className += `-${breakpoint}`;
  }
  if (type === "col") {
    className = "v-" + className;
  }
  if (type === "col" && (val === "" || val === true)) {
    return className.toLowerCase();
  }
  className += `-${val}`;
  return className.toLowerCase();
}
const ALIGN_SELF_VALUES = ["auto", "start", "end", "center", "baseline", "stretch"];
const makeVColProps = propsFactory({
  cols: {
    type: [Boolean, String, Number],
    default: false
  },
  ...breakpointProps,
  offset: {
    type: [String, Number],
    default: null
  },
  ...offsetProps,
  order: {
    type: [String, Number],
    default: null
  },
  ...orderProps,
  alignSelf: {
    type: String,
    default: null,
    validator: (str) => ALIGN_SELF_VALUES.includes(str)
  },
  ...makeComponentProps(),
  ...makeTagProps()
}, "VCol");
const VCol = genericComponent()({
  name: "VCol",
  props: makeVColProps(),
  setup(props, _ref) {
    let {
      slots
    } = _ref;
    const classes = computed(() => {
      const classList = [];
      let type;
      for (type in propMap$1) {
        propMap$1[type].forEach((prop) => {
          const value = props[prop];
          const className = breakpointClass$1(type, prop, value);
          if (className)
            classList.push(className);
        });
      }
      const hasColClasses = classList.some((className) => className.startsWith("v-col-"));
      classList.push({
        // Default to .v-col if no other col-{bp}-* classes generated nor `cols` specified.
        "v-col": !hasColClasses || !props.cols,
        [`v-col-${props.cols}`]: props.cols,
        [`offset-${props.offset}`]: props.offset,
        [`order-${props.order}`]: props.order,
        [`align-self-${props.alignSelf}`]: props.alignSelf
      });
      return classList;
    });
    return () => {
      var _a;
      return h(props.tag, {
        class: [classes.value, props.class],
        style: props.style
      }, (_a = slots.default) == null ? void 0 : _a.call(slots));
    };
  }
});
const ALIGNMENT = ["start", "end", "center"];
const SPACE = ["space-between", "space-around", "space-evenly"];
function makeRowProps(prefix, def) {
  return breakpoints.reduce((props, val) => {
    const prefixKey = prefix + capitalize(val);
    props[prefixKey] = def();
    return props;
  }, {});
}
const ALIGN_VALUES = [...ALIGNMENT, "baseline", "stretch"];
const alignValidator = (str) => ALIGN_VALUES.includes(str);
const alignProps = makeRowProps("align", () => ({
  type: String,
  default: null,
  validator: alignValidator
}));
const JUSTIFY_VALUES = [...ALIGNMENT, ...SPACE];
const justifyValidator = (str) => JUSTIFY_VALUES.includes(str);
const justifyProps = makeRowProps("justify", () => ({
  type: String,
  default: null,
  validator: justifyValidator
}));
const ALIGN_CONTENT_VALUES = [...ALIGNMENT, ...SPACE, "stretch"];
const alignContentValidator = (str) => ALIGN_CONTENT_VALUES.includes(str);
const alignContentProps = makeRowProps("alignContent", () => ({
  type: String,
  default: null,
  validator: alignContentValidator
}));
const propMap = {
  align: Object.keys(alignProps),
  justify: Object.keys(justifyProps),
  alignContent: Object.keys(alignContentProps)
};
const classMap = {
  align: "align",
  justify: "justify",
  alignContent: "align-content"
};
function breakpointClass(type, prop, val) {
  let className = classMap[type];
  if (val == null) {
    return void 0;
  }
  if (prop) {
    const breakpoint = prop.replace(type, "");
    className += `-${breakpoint}`;
  }
  className += `-${val}`;
  return className.toLowerCase();
}
const makeVRowProps = propsFactory({
  dense: Boolean,
  noGutters: Boolean,
  align: {
    type: String,
    default: null,
    validator: alignValidator
  },
  ...alignProps,
  justify: {
    type: String,
    default: null,
    validator: justifyValidator
  },
  ...justifyProps,
  alignContent: {
    type: String,
    default: null,
    validator: alignContentValidator
  },
  ...alignContentProps,
  ...makeComponentProps(),
  ...makeTagProps()
}, "VRow");
const VRow = genericComponent()({
  name: "VRow",
  props: makeVRowProps(),
  setup(props, _ref) {
    let {
      slots
    } = _ref;
    const classes = computed(() => {
      const classList = [];
      let type;
      for (type in propMap) {
        propMap[type].forEach((prop) => {
          const value = props[prop];
          const className = breakpointClass(type, prop, value);
          if (className)
            classList.push(className);
        });
      }
      classList.push({
        "v-row--no-gutters": props.noGutters,
        "v-row--dense": props.dense,
        [`align-${props.align}`]: props.align,
        [`justify-${props.justify}`]: props.justify,
        [`align-content-${props.alignContent}`]: props.alignContent
      });
      return classList;
    });
    return () => {
      var _a;
      return h(props.tag, {
        class: ["v-row", classes.value, props.class],
        style: props.style
      }, (_a = slots.default) == null ? void 0 : _a.call(slots));
    };
  }
});
const VCardActions = genericComponent()({
  name: "VCardActions",
  props: makeComponentProps(),
  setup(props, _ref) {
    let {
      slots
    } = _ref;
    provideDefaults({
      VBtn: {
        slim: true,
        variant: "text"
      }
    });
    useRender(() => {
      var _a;
      return createVNode("div", {
        "class": ["v-card-actions", props.class],
        "style": props.style
      }, [(_a = slots.default) == null ? void 0 : _a.call(slots)]);
    });
    return {};
  }
});
const VCardSubtitle = createSimpleFunctional("v-card-subtitle");
const VCardTitle = createSimpleFunctional("v-card-title");
const makeCardItemProps = propsFactory({
  appendAvatar: String,
  appendIcon: IconValue,
  prependAvatar: String,
  prependIcon: IconValue,
  subtitle: String,
  title: String,
  ...makeComponentProps(),
  ...makeDensityProps()
}, "VCardItem");
const VCardItem = genericComponent()({
  name: "VCardItem",
  props: makeCardItemProps(),
  setup(props, _ref) {
    let {
      slots
    } = _ref;
    useRender(() => {
      var _a;
      const hasPrependMedia = !!(props.prependAvatar || props.prependIcon);
      const hasPrepend = !!(hasPrependMedia || slots.prepend);
      const hasAppendMedia = !!(props.appendAvatar || props.appendIcon);
      const hasAppend = !!(hasAppendMedia || slots.append);
      const hasTitle = !!(props.title || slots.title);
      const hasSubtitle = !!(props.subtitle || slots.subtitle);
      return createVNode("div", {
        "class": ["v-card-item", props.class],
        "style": props.style
      }, [hasPrepend && createVNode("div", {
        "key": "prepend",
        "class": "v-card-item__prepend"
      }, [!slots.prepend ? hasPrependMedia && createVNode(VAvatar, {
        "key": "prepend-avatar",
        "density": props.density,
        "icon": props.prependIcon,
        "image": props.prependAvatar
      }, null) : createVNode(VDefaultsProvider, {
        "key": "prepend-defaults",
        "disabled": !hasPrependMedia,
        "defaults": {
          VAvatar: {
            density: props.density,
            icon: props.prependIcon,
            image: props.prependAvatar
          }
        }
      }, slots.prepend)]), createVNode("div", {
        "class": "v-card-item__content"
      }, [hasTitle && createVNode(VCardTitle, {
        "key": "title"
      }, {
        default: () => {
          var _a3;
          var _a2;
          return [(_a3 = (_a2 = slots.title) == null ? void 0 : _a2.call(slots)) != null ? _a3 : props.title];
        }
      }), hasSubtitle && createVNode(VCardSubtitle, {
        "key": "subtitle"
      }, {
        default: () => {
          var _a3;
          var _a2;
          return [(_a3 = (_a2 = slots.subtitle) == null ? void 0 : _a2.call(slots)) != null ? _a3 : props.subtitle];
        }
      }), (_a = slots.default) == null ? void 0 : _a.call(slots)]), hasAppend && createVNode("div", {
        "key": "append",
        "class": "v-card-item__append"
      }, [!slots.append ? hasAppendMedia && createVNode(VAvatar, {
        "key": "append-avatar",
        "density": props.density,
        "icon": props.appendIcon,
        "image": props.appendAvatar
      }, null) : createVNode(VDefaultsProvider, {
        "key": "append-defaults",
        "disabled": !hasAppendMedia,
        "defaults": {
          VAvatar: {
            density: props.density,
            icon: props.appendIcon,
            image: props.appendAvatar
          }
        }
      }, slots.append)])]);
    });
    return {};
  }
});
const VCardText = createSimpleFunctional("v-card-text");
const makeVCardProps = propsFactory({
  appendAvatar: String,
  appendIcon: IconValue,
  disabled: Boolean,
  flat: Boolean,
  hover: Boolean,
  image: String,
  link: {
    type: Boolean,
    default: void 0
  },
  prependAvatar: String,
  prependIcon: IconValue,
  ripple: {
    type: [Boolean, Object],
    default: true
  },
  subtitle: String,
  text: String,
  title: String,
  ...makeBorderProps(),
  ...makeComponentProps(),
  ...makeDensityProps(),
  ...makeDimensionProps(),
  ...makeElevationProps(),
  ...makeLoaderProps(),
  ...makeLocationProps(),
  ...makePositionProps(),
  ...makeRoundedProps(),
  ...makeRouterProps(),
  ...makeTagProps(),
  ...makeThemeProps(),
  ...makeVariantProps({
    variant: "elevated"
  })
}, "VCard");
const VCard = genericComponent()({
  name: "VCard",
  directives: {
    Ripple
  },
  props: makeVCardProps(),
  setup(props, _ref) {
    let {
      attrs,
      slots
    } = _ref;
    const {
      themeClasses
    } = provideTheme(props);
    const {
      borderClasses
    } = useBorder(props);
    const {
      colorClasses,
      colorStyles,
      variantClasses
    } = useVariant(props);
    const {
      densityClasses
    } = useDensity(props);
    const {
      dimensionStyles
    } = useDimension(props);
    const {
      elevationClasses
    } = useElevation(props);
    const {
      loaderClasses
    } = useLoader(props);
    const {
      locationStyles
    } = useLocation(props);
    const {
      positionClasses
    } = usePosition(props);
    const {
      roundedClasses
    } = useRounded(props);
    const link = useLink(props, attrs);
    const isLink = computed(() => props.link !== false && link.isLink.value);
    const isClickable = computed(() => !props.disabled && props.link !== false && (props.link || link.isClickable.value));
    useRender(() => {
      const Tag = isLink.value ? "a" : props.tag;
      const hasTitle = !!(slots.title || props.title);
      const hasSubtitle = !!(slots.subtitle || props.subtitle);
      const hasHeader = hasTitle || hasSubtitle;
      const hasAppend = !!(slots.append || props.appendAvatar || props.appendIcon);
      const hasPrepend = !!(slots.prepend || props.prependAvatar || props.prependIcon);
      const hasImage = !!(slots.image || props.image);
      const hasCardItem = hasHeader || hasPrepend || hasAppend;
      const hasText = !!(slots.text || props.text);
      return withDirectives(createVNode(Tag, {
        "class": ["v-card", {
          "v-card--disabled": props.disabled,
          "v-card--flat": props.flat,
          "v-card--hover": props.hover && !(props.disabled || props.flat),
          "v-card--link": isClickable.value
        }, themeClasses.value, borderClasses.value, colorClasses.value, densityClasses.value, elevationClasses.value, loaderClasses.value, positionClasses.value, roundedClasses.value, variantClasses.value, props.class],
        "style": [colorStyles.value, dimensionStyles.value, locationStyles.value, props.style],
        "href": link.href.value,
        "onClick": isClickable.value && link.navigate,
        "tabindex": props.disabled ? -1 : void 0
      }, {
        default: () => {
          var _a;
          return [hasImage && createVNode("div", {
            "key": "image",
            "class": "v-card__image"
          }, [!slots.image ? createVNode(VImg, {
            "key": "image-img",
            "cover": true,
            "src": props.image
          }, null) : createVNode(VDefaultsProvider, {
            "key": "image-defaults",
            "disabled": !props.image,
            "defaults": {
              VImg: {
                cover: true,
                src: props.image
              }
            }
          }, slots.image)]), createVNode(LoaderSlot, {
            "name": "v-card",
            "active": !!props.loading,
            "color": typeof props.loading === "boolean" ? void 0 : props.loading
          }, {
            default: slots.loader
          }), hasCardItem && createVNode(VCardItem, {
            "key": "item",
            "prependAvatar": props.prependAvatar,
            "prependIcon": props.prependIcon,
            "title": props.title,
            "subtitle": props.subtitle,
            "appendAvatar": props.appendAvatar,
            "appendIcon": props.appendIcon
          }, {
            default: slots.item,
            prepend: slots.prepend,
            title: slots.title,
            subtitle: slots.subtitle,
            append: slots.append
          }), hasText && createVNode(VCardText, {
            "key": "text"
          }, {
            default: () => {
              var _a3;
              var _a2;
              return [(_a3 = (_a2 = slots.text) == null ? void 0 : _a2.call(slots)) != null ? _a3 : props.text];
            }
          }), (_a = slots.default) == null ? void 0 : _a.call(slots), slots.actions && createVNode(VCardActions, null, {
            default: slots.actions
          }), genOverlays(isClickable.value, "v-card")];
        }
      }), [[resolveDirective("ripple"), isClickable.value && props.ripple]]);
    });
    return {};
  }
});
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const cards = ["Today", "Yesterday"];
    useHead({
      title: "HOME",
      meta: [{ name: "description", content: "HPME\u30DA\u30FC\u30B8\u306Edescription\u3067\u3059\u3002" }]
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(VContainer, mergeProps({
        class: "py-8 px-6",
        fluid: ""
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VRow, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(cards, (card) => {
                    _push3(ssrRenderComponent(VCol, {
                      key: card,
                      cols: "12"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(VCard, null, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(VList, { lines: "two" }, {
                                  default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      _push6(ssrRenderComponent(VListSubheader, { title: card }, null, _parent6, _scopeId5));
                                      _push6(`<!--[-->`);
                                      ssrRenderList(6, (n) => {
                                        _push6(`<!--[-->`);
                                        _push6(ssrRenderComponent(VListItem, null, {
                                          prepend: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                            if (_push7) {
                                              _push7(ssrRenderComponent(VAvatar, { color: "grey-darken-1" }, null, _parent7, _scopeId6));
                                            } else {
                                              return [
                                                createVNode(VAvatar, { color: "grey-darken-1" })
                                              ];
                                            }
                                          }),
                                          default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                            if (_push7) {
                                              _push7(ssrRenderComponent(VListItemTitle, {
                                                title: `Message ${n}`
                                              }, null, _parent7, _scopeId6));
                                              _push7(ssrRenderComponent(VListItemSubtitle, { title: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil repellendus distinctio similique" }, null, _parent7, _scopeId6));
                                            } else {
                                              return [
                                                createVNode(VListItemTitle, {
                                                  title: `Message ${n}`
                                                }, null, 8, ["title"]),
                                                createVNode(VListItemSubtitle, { title: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil repellendus distinctio similique" })
                                              ];
                                            }
                                          }),
                                          _: 2
                                        }, _parent6, _scopeId5));
                                        if (n !== 6) {
                                          _push6(ssrRenderComponent(VDivider, {
                                            key: `divider-${n}`,
                                            inset: ""
                                          }, null, _parent6, _scopeId5));
                                        } else {
                                          _push6(`<!---->`);
                                        }
                                        _push6(`<!--]-->`);
                                      });
                                      _push6(`<!--]-->`);
                                    } else {
                                      return [
                                        createVNode(VListSubheader, { title: card }, null, 8, ["title"]),
                                        (openBlock(), createBlock(Fragment, null, renderList(6, (n) => {
                                          return openBlock(), createBlock(Fragment, { key: n }, [
                                            createVNode(VListItem, null, {
                                              prepend: withCtx(() => [
                                                createVNode(VAvatar, { color: "grey-darken-1" })
                                              ]),
                                              default: withCtx(() => [
                                                createVNode(VListItemTitle, {
                                                  title: `Message ${n}`
                                                }, null, 8, ["title"]),
                                                createVNode(VListItemSubtitle, { title: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil repellendus distinctio similique" })
                                              ]),
                                              _: 2
                                            }, 1024),
                                            n !== 6 ? (openBlock(), createBlock(VDivider, {
                                              key: `divider-${n}`,
                                              inset: ""
                                            })) : createCommentVNode("", true)
                                          ], 64);
                                        }), 64))
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(VList, { lines: "two" }, {
                                    default: withCtx(() => [
                                      createVNode(VListSubheader, { title: card }, null, 8, ["title"]),
                                      (openBlock(), createBlock(Fragment, null, renderList(6, (n) => {
                                        return openBlock(), createBlock(Fragment, { key: n }, [
                                          createVNode(VListItem, null, {
                                            prepend: withCtx(() => [
                                              createVNode(VAvatar, { color: "grey-darken-1" })
                                            ]),
                                            default: withCtx(() => [
                                              createVNode(VListItemTitle, {
                                                title: `Message ${n}`
                                              }, null, 8, ["title"]),
                                              createVNode(VListItemSubtitle, { title: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil repellendus distinctio similique" })
                                            ]),
                                            _: 2
                                          }, 1024),
                                          n !== 6 ? (openBlock(), createBlock(VDivider, {
                                            key: `divider-${n}`,
                                            inset: ""
                                          })) : createCommentVNode("", true)
                                        ], 64);
                                      }), 64))
                                    ]),
                                    _: 2
                                  }, 1024)
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(VCard, null, {
                              default: withCtx(() => [
                                createVNode(VList, { lines: "two" }, {
                                  default: withCtx(() => [
                                    createVNode(VListSubheader, { title: card }, null, 8, ["title"]),
                                    (openBlock(), createBlock(Fragment, null, renderList(6, (n) => {
                                      return openBlock(), createBlock(Fragment, { key: n }, [
                                        createVNode(VListItem, null, {
                                          prepend: withCtx(() => [
                                            createVNode(VAvatar, { color: "grey-darken-1" })
                                          ]),
                                          default: withCtx(() => [
                                            createVNode(VListItemTitle, {
                                              title: `Message ${n}`
                                            }, null, 8, ["title"]),
                                            createVNode(VListItemSubtitle, { title: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil repellendus distinctio similique" })
                                          ]),
                                          _: 2
                                        }, 1024),
                                        n !== 6 ? (openBlock(), createBlock(VDivider, {
                                          key: `divider-${n}`,
                                          inset: ""
                                        })) : createCommentVNode("", true)
                                      ], 64);
                                    }), 64))
                                  ]),
                                  _: 2
                                }, 1024)
                              ]),
                              _: 2
                            }, 1024)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(), createBlock(Fragment, null, renderList(cards, (card) => {
                      return createVNode(VCol, {
                        key: card,
                        cols: "12"
                      }, {
                        default: withCtx(() => [
                          createVNode(VCard, null, {
                            default: withCtx(() => [
                              createVNode(VList, { lines: "two" }, {
                                default: withCtx(() => [
                                  createVNode(VListSubheader, { title: card }, null, 8, ["title"]),
                                  (openBlock(), createBlock(Fragment, null, renderList(6, (n) => {
                                    return openBlock(), createBlock(Fragment, { key: n }, [
                                      createVNode(VListItem, null, {
                                        prepend: withCtx(() => [
                                          createVNode(VAvatar, { color: "grey-darken-1" })
                                        ]),
                                        default: withCtx(() => [
                                          createVNode(VListItemTitle, {
                                            title: `Message ${n}`
                                          }, null, 8, ["title"]),
                                          createVNode(VListItemSubtitle, { title: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil repellendus distinctio similique" })
                                        ]),
                                        _: 2
                                      }, 1024),
                                      n !== 6 ? (openBlock(), createBlock(VDivider, {
                                        key: `divider-${n}`,
                                        inset: ""
                                      })) : createCommentVNode("", true)
                                    ], 64);
                                  }), 64))
                                ]),
                                _: 2
                              }, 1024)
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1024);
                    }), 64))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VRow, null, {
                default: withCtx(() => [
                  (openBlock(), createBlock(Fragment, null, renderList(cards, (card) => {
                    return createVNode(VCol, {
                      key: card,
                      cols: "12"
                    }, {
                      default: withCtx(() => [
                        createVNode(VCard, null, {
                          default: withCtx(() => [
                            createVNode(VList, { lines: "two" }, {
                              default: withCtx(() => [
                                createVNode(VListSubheader, { title: card }, null, 8, ["title"]),
                                (openBlock(), createBlock(Fragment, null, renderList(6, (n) => {
                                  return openBlock(), createBlock(Fragment, { key: n }, [
                                    createVNode(VListItem, null, {
                                      prepend: withCtx(() => [
                                        createVNode(VAvatar, { color: "grey-darken-1" })
                                      ]),
                                      default: withCtx(() => [
                                        createVNode(VListItemTitle, {
                                          title: `Message ${n}`
                                        }, null, 8, ["title"]),
                                        createVNode(VListItemSubtitle, { title: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil repellendus distinctio similique" })
                                      ]),
                                      _: 2
                                    }, 1024),
                                    n !== 6 ? (openBlock(), createBlock(VDivider, {
                                      key: `divider-${n}`,
                                      inset: ""
                                    })) : createCommentVNode("", true)
                                  ], 64);
                                }), 64))
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1024);
                  }), 64))
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-94bbd365.mjs.map
